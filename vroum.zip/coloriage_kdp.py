#!/usr/bin/env python3
"""
Generateur de cahiers de coloriage prets pour Amazon KDP.

Deux modes :
  1) --mode motifs  : genere des dessins vectoriels (mandalas, labyrinthes,
                      geometrie, vagues) directement dans le PDF.
  2) --mode images  : assemble tes propres images (PNG/JPG en 300 DPI)
                      dans un PDF conforme KDP.

Specs respectees :
  - Format 8.5 x 11 pouces, sans fond perdu (No Bleed)
  - Marge exterieure 0.5", marge interieure (reliure) 0.5"
  - Impression recto seul : une page blanche derriere chaque dessin
  - Trait vectoriel = pas de probleme de DPI (mode motifs)
  - Niveaux de gris / noir pur

Usage :
  python3 coloriage_kdp.py --mode motifs --nb 20 --sortie mon_cahier.pdf
  python3 coloriage_kdp.py --mode images --dossier ./mes_dessins --sortie mon_cahier.pdf
"""

import argparse
import math
import os
import random

from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from PIL import Image as PILImage

# ---------------------------------------------------------------- specs KDP
LARGEUR, HAUTEUR = 8.5 * inch, 11 * inch
MARGE_EXT = 0.5 * inch          # haut, bas, bord exterieur
MARGE_RELIURE = 0.5 * inch      # cote reliure (suffisant jusqu'a 300 pages)
TRAIT_EPAIS = 2.2               # style "bold & easy"
TRAIT_FIN = 1.1                 # style detaille


def zone_dessin(page_impaire=True):
    """Retourne (x, y, largeur, hauteur) de la zone utile.
    Les dessins sont toujours en page impaire (recto) : reliure a gauche."""
    x = MARGE_RELIURE if page_impaire else MARGE_EXT
    largeur = LARGEUR - MARGE_RELIURE - MARGE_EXT
    return x, MARGE_EXT, largeur, HAUTEUR - 2 * MARGE_EXT


# ------------------------------------------------------------------ motifs
def mandala(c, cx, cy, rayon, rng):
    """Mandala : anneaux concentriques de motifs repetes."""
    c.setLineWidth(TRAIT_EPAIS)
    n_anneaux = rng.randint(5, 7)
    rayons = [rayon * (i + 1) / n_anneaux for i in range(n_anneaux)]

    c.circle(cx, cy, rayons[0] * 0.45, stroke=1, fill=0)
    c.circle(cx, cy, rayons[0] * 0.25, stroke=1, fill=0)

    for i, r in enumerate(rayons):
        c.setLineWidth(TRAIT_EPAIS if i % 2 == 0 else TRAIT_FIN + 0.4)
        c.circle(cx, cy, r, stroke=1, fill=0)
        r_int = rayons[i - 1] if i > 0 else rayons[0] * 0.45
        motif = rng.choice(["petale", "goutte", "triangle", "arc", "cercles"])
        n = rng.choice([8, 10, 12, 16])
        for k in range(n):
            a = 2 * math.pi * k / n + (math.pi / n if i % 2 else 0)
            _motif_radial(c, cx, cy, r_int, r, a, n, motif)

    # bordure festonnee exterieure
    c.setLineWidth(TRAIT_EPAIS)
    n = rng.choice([18, 24, 30])
    rf = rayon * 1.06
    for k in range(n):
        a = 2 * math.pi * k / n
        c.circle(cx + rf * math.cos(a), cy + rf * math.sin(a),
                 rf * math.pi / n * 0.9, stroke=1, fill=0)


def _motif_radial(c, cx, cy, r0, r1, angle, n, motif):
    largeur_ang = math.pi / n * 0.85
    p1 = (cx + r0 * math.cos(angle), cy + r0 * math.sin(angle))
    p2 = (cx + r1 * math.cos(angle - largeur_ang), cy + r1 * math.sin(angle - largeur_ang))
    p3 = (cx + r1 * math.cos(angle + largeur_ang), cy + r1 * math.sin(angle + largeur_ang))

    if motif == "petale":
        p = c.beginPath()
        p.moveTo(*p1)
        p.curveTo(p2[0], p2[1], p3[0], p3[1], *p1)
        c.drawPath(p, stroke=1, fill=0)
    elif motif == "goutte":
        rm = (r0 + r1) / 2
        c.circle(cx + rm * math.cos(angle), cy + rm * math.sin(angle),
                 (r1 - r0) * 0.32, stroke=1, fill=0)
    elif motif == "triangle":
        p = c.beginPath()
        p.moveTo(*p1)
        p.lineTo(*p2)
        p.lineTo(*p3)
        p.close()
        c.drawPath(p, stroke=1, fill=0)
    elif motif == "arc":
        c.line(p1[0], p1[1], cx + r1 * math.cos(angle), cy + r1 * math.sin(angle))
    else:  # cercles
        rm = r0 + (r1 - r0) * 0.5
        for f in (0.35, 0.65):
            rr = r0 + (r1 - r0) * f
            c.circle(cx + rr * math.cos(angle), cy + rr * math.sin(angle),
                     (r1 - r0) * 0.16, stroke=1, fill=0)


def labyrinthe(c, x, y, w, h, rng):
    """Labyrinthe parfait genere par parcours en profondeur."""
    cols = rng.choice([14, 16, 18])
    taille = w / cols
    lignes = int(h / taille)
    murs_v = [[True] * (cols + 1) for _ in range(lignes)]
    murs_h = [[True] * cols for _ in range(lignes + 1)]
    vus = [[False] * cols for _ in range(lignes)]

    pile = [(0, 0)]
    vus[0][0] = True
    while pile:
        cy_, cx_ = pile[-1]
        voisins = []
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            ny, nx = cy_ + dy, cx_ + dx
            if 0 <= ny < lignes and 0 <= nx < cols and not vus[ny][nx]:
                voisins.append((ny, nx, dy, dx))
        if not voisins:
            pile.pop()
            continue
        ny, nx, dy, dx = rng.choice(voisins)
        if dx == 1:
            murs_v[cy_][cx_ + 1] = False
        elif dx == -1:
            murs_v[cy_][cx_] = False
        elif dy == 1:
            murs_h[cy_ + 1][cx_] = False
        else:
            murs_h[cy_][cx_] = False
        vus[ny][nx] = True
        pile.append((ny, nx))

    murs_h[0][0] = False                 # entree
    murs_h[lignes][cols - 1] = False     # sortie

    c.setLineWidth(TRAIT_EPAIS)
    c.setLineCap(1)
    y0 = y + (h - lignes * taille) / 2
    for r in range(lignes):
        for col in range(cols + 1):
            if murs_v[r][col]:
                px = x + col * taille
                c.line(px, y0 + r * taille, px, y0 + (r + 1) * taille)
    for r in range(lignes + 1):
        for col in range(cols):
            if murs_h[r][col]:
                py = y0 + r * taille
                c.line(x + col * taille, py, x + (col + 1) * taille, py)


def geometrie(c, x, y, w, h, rng):
    """Grille de cellules geometriques imbriquees."""
    cols = rng.choice([3, 4, 5])
    taille = w / cols
    lignes = int(h / taille)
    y0 = y + (h - lignes * taille) / 2
    c.setLineWidth(TRAIT_EPAIS)
    for r in range(lignes):
        for col in range(cols):
            cx_, cy_ = x + (col + .5) * taille, y0 + (r + .5) * taille
            c.rect(x + col * taille, y0 + r * taille, taille, taille, stroke=1, fill=0)
            forme = rng.choice(["cercles", "losanges", "eventail", "carres"])
            if forme == "cercles":
                for f in (0.42, 0.30, 0.16):
                    c.circle(cx_, cy_, taille * f, stroke=1, fill=0)
            elif forme == "losanges":
                for f in (0.46, 0.30, 0.15):
                    p = c.beginPath()
                    p.moveTo(cx_, cy_ + taille * f)
                    p.lineTo(cx_ + taille * f, cy_)
                    p.lineTo(cx_, cy_ - taille * f)
                    p.lineTo(cx_ - taille * f, cy_)
                    p.close()
                    c.drawPath(p, stroke=1, fill=0)
            elif forme == "eventail":
                n = 7
                bx, by = x + col * taille, y0 + r * taille
                for k in range(1, n):
                    rr = taille * k / n
                    p = c.beginPath()
                    p.moveTo(bx + rr, by)
                    p.curveTo(bx + rr, by + rr * .55, bx + rr * .55, by + rr, bx, by + rr)
                    c.drawPath(p, stroke=1, fill=0)
            else:
                for f in (0.40, 0.26, 0.12):
                    c.rect(cx_ - taille * f, cy_ - taille * f,
                           taille * 2 * f, taille * 2 * f, stroke=1, fill=0)


def vagues(c, x, y, w, h, rng):
    """Bandes ondulantes remplies de petits motifs (style zentangle)."""
    n_bandes = rng.randint(7, 10)
    hb = h / n_bandes
    c.setLineWidth(TRAIT_EPAIS)
    for i in range(n_bandes + 1):
        yb = y + i * hb
        amp = rng.uniform(hb * .15, hb * .45)
        periodes = rng.randint(2, 4)
        p = c.beginPath()
        p.moveTo(x, yb)
        pas = w / 60
        px = x
        while px <= x + w:
            py = yb + amp * math.sin(2 * math.pi * periodes * (px - x) / w)
            p.lineTo(px, py)
            px += pas
        c.drawPath(p, stroke=1, fill=0)
        if i < n_bandes and rng.random() < .6:
            c.setLineWidth(TRAIT_FIN)
            n = rng.randint(6, 12)
            for k in range(n):
                cx_ = x + w * (k + .5) / n
                c.circle(cx_, yb + hb * .5, min(hb * .18, w / n * .3), stroke=1, fill=0)
            c.setLineWidth(TRAIT_EPAIS)


MOTIFS = ["mandala", "labyrinthe", "geometrie", "vagues"]


def dessiner_motif(c, nom, rng):
    x, y, w, h = zone_dessin(page_impaire=True)
    c.setStrokeColorRGB(0, 0, 0)
    if nom == "mandala":
        cote = min(w, h)
        mandala(c, x + w / 2, y + h / 2, cote * .44, rng)
    elif nom == "labyrinthe":
        labyrinthe(c, x, y, w, h, rng)
    elif nom == "geometrie":
        geometrie(c, x, y, w, h, rng)
    else:
        vagues(c, x, y, w, h, rng)


# -------------------------------------------------------------- assemblage
def page_titre(c, titre, sous_titre):
    c.setFillColorRGB(0, 0, 0)
    c.setFont("Helvetica-Bold", 26)
    c.drawCentredString(LARGEUR / 2, HAUTEUR * .60, titre[:60])
    if sous_titre:
        c.setFont("Helvetica", 14)
        c.drawCentredString(LARGEUR / 2, HAUTEUR * .55, sous_titre[:80])
    c.setFont("Helvetica", 9)
    c.drawCentredString(LARGEUR / 2, HAUTEUR * .12, "Ce livre appartient a : ______________________")
    c.showPage()
    c.showPage()  # verso blanc


def construire(sortie, mode, nb, dossier, titre, sous_titre, graine):
    rng = random.Random(graine)
    c = canvas.Canvas(sortie, pagesize=(LARGEUR, HAUTEUR))
    c.setTitle(titre)

    page_titre(c, titre, sous_titre)

    if mode == "motifs":
        sequence = []
        while len(sequence) < nb:
            lot = MOTIFS[:]
            rng.shuffle(lot)
            sequence.extend(lot)
        sequence = sequence[:nb]
        for nom in sequence:
            dessiner_motif(c, nom, rng)
            c.showPage()   # page dessin
            c.showPage()   # verso blanc
    else:
        exts = (".png", ".jpg", ".jpeg", ".tif", ".tiff")
        fichiers = sorted(f for f in os.listdir(dossier) if f.lower().endswith(exts))
        if not fichiers:
            raise SystemExit(f"Aucune image trouvee dans {dossier}")
        x, y, w, h = zone_dessin(page_impaire=True)
        ratio_page = LARGEUR / HAUTEUR
        for f in fichiers:
            chemin = os.path.join(dossier, f)
            # aplatir la transparence sur blanc + passer en niveaux de gris
            src = PILImage.open(chemin)
            if src.mode in ("RGBA", "LA", "P"):
                src = src.convert("RGBA")
                fond = PILImage.new("RGBA", src.size, (255, 255, 255, 255))
                src = PILImage.alpha_composite(fond, src)
            src = src.convert("L")
            img = ImageReader(src)
            iw, ih = src.size
            if abs(iw / ih - ratio_page) < 0.02:
                # image deja au format de la page : placement pleine page,
                # ses propres marges font foi
                c.drawImage(img, 0, 0, LARGEUR, HAUTEUR)
            else:
                echelle = min(w / iw, h / ih)
                dw, dh = iw * echelle, ih * echelle
                c.drawImage(img, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh)
            c.showPage()
            c.showPage()
        nb = len(fichiers)

    c.save()
    total = 2 + nb * 2
    print(f"OK -> {sortie}")
    print(f"   {nb} dessins, {total} pages au total (minimum KDP : 24)")
    if total < 24:
        print("   ATTENTION : moins de 24 pages, KDP refusera. Ajoute des dessins.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["motifs", "images"], default="motifs")
    ap.add_argument("--nb", type=int, default=40, help="nombre de dessins (mode motifs)")
    ap.add_argument("--dossier", default="./dessins", help="dossier d'images (mode images)")
    ap.add_argument("--sortie", default="cahier_coloriage.pdf")
    ap.add_argument("--titre", default="Cahier de coloriage")
    ap.add_argument("--sous-titre", dest="sous_titre", default="")
    ap.add_argument("--graine", type=int, default=7, help="graine aleatoire : change-la pour un autre livre")
    a = ap.parse_args()
    construire(a.sortie, a.mode, a.nb, a.dossier, a.titre, a.sous_titre, a.graine)
